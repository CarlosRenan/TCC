package com.crdev.papaleguas.model;



public class Corrida {
}
